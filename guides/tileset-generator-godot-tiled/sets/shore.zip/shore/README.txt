shore — Pixelbolt tile set

shore.png: transparent RGBA tile sheet
shore.tileset.tres: Godot 4 TileSet with the layered terrains water, sand and grass and their transitions, and collision shapes on physics layer 0; it finds shore.png in its own folder, so keep the two together
shore.tsx: Tiled tileset with the layered terrains water, sand and grass and their transitions, and collision shapes in each tile's collision group; it finds shore.png in its own folder
shore.atlas.json: TexturePacker-style frames, with each tile's terrain, weight and collision polygons (in exported pixels) where the recipe gives them
frames/: one PNG per tile
shore.pixel.json: editable source
preview.html: the tile sheet; open it directly in a browser

Godot 4: copy shore.png and shore.tileset.tres into one folder of your project. Add a TileMapLayer and set its Tile Set to shore.tileset.tres. For the layered terrains, paint bottom-up, each terrain over its own cells and those of every terrain above it: water over the whole area, then sand over the sand and grass, then grass over the grass. Godot puts a terrain where four cells painted with it meet, so each ends half a cell inside what you paint, and the transitions between terrains appear on their own. Set the layer's Texture Filter to Nearest for crisp pixels. Bodies collide with the tiles on the physics layer's collision layer 1.

Tiled: in a map of 16×16 tiles, Map > Add External Tileset and pick shore.tsx. In the Terrain Sets view pick a terrain set and paint with the Terrain Brush. The layered terrains water, sand and grass are painted on the points where four cells meet, a point of Tiled's map being a cell of Pixelbolt's, and every mix of them has its tile: paint each terrain where its cells are. Collision shapes are in each tile's collision group (the Tile Collision Editor).
