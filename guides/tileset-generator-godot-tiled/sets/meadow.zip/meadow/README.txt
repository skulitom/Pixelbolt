meadow — Pixelbolt tile set

meadow.png: transparent RGBA tile sheet
meadow.tileset.tres: Godot 4 TileSet with the terrain meadow; it finds meadow.png in its own folder, so keep the two together
meadow.tsx: Tiled tileset with the terrain meadow; it finds meadow.png in its own folder
meadow.atlas.json: TexturePacker-style frames, with each tile's terrain, weight and collision polygons (in exported pixels) where the recipe gives them
frames/: one PNG per tile
meadow.pixel.json: editable source
preview.html: the tile sheet; open it directly in a browser

Godot 4: copy meadow.png and meadow.tileset.tres into one folder of your project. Add a TileMapLayer and set its Tile Set to meadow.tileset.tres. In the TileMap panel's Terrains tab, pick meadow and paint: Godot picks each cell's tile from its neighbours, as Pixelbolt's tilemaps do. Set the layer's Texture Filter to Nearest for crisp pixels.

Tiled: in a map of 16×16 tiles, Map > Add External Tileset and pick meadow.tsx. In the Terrain Sets view pick a terrain set and paint with the Terrain Brush. A blob or cardinal terrain is painted on the sides and corners between cells, so a lone cell, with its terrain on no side, has no terrain tile: place it by hand.
