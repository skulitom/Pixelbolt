ground — Pixelbolt tile set

ground.png: transparent RGBA tile sheet
ground.tileset.tres: Godot 4 TileSet with the terrain ground and 10 plain tiles, and collision shapes on physics layer 0; it finds ground.png in its own folder, so keep the two together
ground.tsx: Tiled tileset with the terrain ground and 10 plain tiles, and collision shapes in each tile's collision group; it finds ground.png in its own folder
ground.atlas.json: TexturePacker-style frames, with each tile's terrain, weight and collision polygons (in exported pixels) where the recipe gives them
frames/: one PNG per tile
ground.pixel.json: editable source
preview.html: the tile sheet; open it directly in a browser

Godot 4: copy ground.png and ground.tileset.tres into one folder of your project. Add a TileMapLayer and set its Tile Set to ground.tileset.tres. In the TileMap panel's Terrains tab, pick ground and paint: Godot picks each cell's tile from its neighbours, as Pixelbolt's tilemaps do. Set the layer's Texture Filter to Nearest for crisp pixels. Bodies collide with the tiles on the physics layer's collision layer 1.

Tiled: in a map of 16×16 tiles, Map > Add External Tileset and pick ground.tsx. In the Terrain Sets view pick a terrain set and paint with the Terrain Brush. A blob or cardinal terrain is painted on the sides and corners between cells, so a lone cell, with its terrain on no side, has no terrain tile: place it by hand. Collision shapes are in each tile's collision group (the Tile Collision Editor).
