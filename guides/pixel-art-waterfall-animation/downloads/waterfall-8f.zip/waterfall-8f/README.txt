Pixel art waterfall, 8 frames
Made with Pixelbolt 0.15.0 (https://github.com/skulitom/Pixelbolt) on 10 November 2026.
From https://skulitom.github.io/Pixelbolt/guides/pixel-art-waterfall-animation/

48 x 64 pixels, 8 frames of 180 ms, looping, 9 colours, transparent background.

waterfall-8f-strip.png        every frame in one row (384 x 64)
waterfall.png             the same frames as a grid sheet, with:
waterfall.atlas.json      frame rectangles, durations and the animation (TexturePacker-style, with Aseprite-style tags)
waterfall.tres            Godot 4 SpriteFrames (keep it next to waterfall.png)
waterfall-8f.gif, waterfall-8f-4x.gif   the loop at 1x and 4x
frames/                each frame as a PNG, renamed by us waterfall-8f-00.png, -01 ... so that name order is playing order
animations/            the loop as an animated PNG
waterfall.fluid.json      the recipe (the short JSON file that describes the simulation): edit it and compile again
waterfall.pixel.json      the compiled result: every frame, as Pixelbolt's own editable file
waterfall.css, player.js, preview.html   Pixelbolt's other export files
LICENSE.txt            the MIT licence (it names "PixelForge contributors": PixelForge is Pixelbolt's earlier name)

Licence: MIT. Free for any use, commercial too; keep the licence text with copies of these files.
The recipe is Pixelbolt's shipped waterfall example, compiled with --frames 8. This zip was made by AI agents working for Pixelbolt's maintainers.
